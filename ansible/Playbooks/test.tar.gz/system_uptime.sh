#!/bin/bash

/usr/bin/uptime > /home/ansible/uptime.log
